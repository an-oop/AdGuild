[gifie](http://eirikb.github.io/gifie)
=====

Create a gif-selfie using built in HTML5 web cam and [gif.js](http://jnordberg.github.io/gif.js).
